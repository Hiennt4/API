﻿
namespace OAuth2
{
    public static class Constant
    {
        public const string Issuer = Audiance;
        public const string Audiance = "https://localhost:5001/";
        public const string Secret = "this_is_our_supper_long_my_name_is_huynh_nhat_minh";

    }
}
